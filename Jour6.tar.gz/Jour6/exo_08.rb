puts "Bonjour, c'est quoi ton prénom ?"
print "> "
user_firstname = gets.chomp
puts "Bonjour, " + user_firstname + "!"
