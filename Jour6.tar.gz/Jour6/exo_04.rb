puts 'puts "Salut, ça farte ?'
