puts "Bonjour, c'est quoi ton prénom ?"
print "> "
user_firstname = gets.chomp
puts "Et ton nom de famille  ?"
print "> "
user_lastname = gets.chomp
puts "Bonjour, " + user_firstname +" "+ user_lastname +"!"
