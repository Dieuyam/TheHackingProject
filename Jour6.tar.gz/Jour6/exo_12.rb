puts "Salut fréro je compte jusqu'à combien ?"
print "> "
farte = gets.to_i

farte.times do |i|
puts "#{i +1}"
end
