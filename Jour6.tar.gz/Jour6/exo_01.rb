puts "Bonjour, monde !"
