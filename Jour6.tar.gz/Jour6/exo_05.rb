# #{} permet d'ecrire du code ruby qui seras executé comme variable dans le code final
puts "On va compter le nombre d'heures de travail à THP" #Cette ligne affiche une chaine de caracteres
puts "Travail : #{10 * 5 * 11}" #Cette ligne affiche une chaine de caracteres suivis de l'execution d'une commande qui affiche 550
puts "En minutes ça fait : #{10 * 5 * 11 * 60}"  #Cette ligne affiche une chaine de caracteres suivis de l'execution d'une commande qui affiche 33000

puts "Et en secondes ?" #Cette ligne affiche une chaine de caracteres

puts 10 * 5 * 11 * 60 * 60 #Cette ligne execute un calcul et l'affiche

puts "Est-ce que c'est vrai que 3 + 2 < 5 - 7 ?" #Cette ligne affiche une chaine de caracteres

puts 3 + 2 < 5 - 7 #Cette ligne execute deux calculs et l'affiche si l'inéquation est vérifiée

puts "Ça fait combien 3 + 2 ? #{3 + 2}" #Cette ligne affiche une chaine de caracteres suivis de l'execution d'une commande qui affiche execute deux calculs et l'affiche si l'inéquation est vérifiée
puts "Ça fait combien 5 - 7 ? #{5 - 7}" #Cette ligne affiche une chaine de caracteres suivis de l'execution d'une commande qui affiche execute deux calculs et l'affiche si l'inéquation est vérifiée

puts "Ok, c'est faux alors !" #Cette ligne affiche une chaine de caracteres

puts "C'est drôle ça, faisons-en plus :" #Cette ligne affiche une chaine de caracteres

puts "Est-ce que 5 est plus grand que -2 ? #{5 > -2}" #Cette ligne affiche une chaine de caracteres suivis de l'execution d'une commande qui affiche 5
puts "Est-ce que 5 est supérieur ou égal à -2 ? #{5 >= -2}" #Cette ligne affiche une chaine de caracteres suivis de l'execution d'une commande qui affiche 5
puts "Est-ce que 5 est inférieur ou égal à -2 ? #{5 <= -2}" #Cette ligne affiche une chaine de caracteres suivis de l'execution d'une commande qui affiche 5
