number_of_hours_worked_per_day = 10
number_of_days_worked_per_week = 5
number_of_weeks_in_THP = 11

puts "Travail : #{number_of_hours_worked_per_day * number_of_days_worked_per_week * number_of_weeks_in_THP}" #Cette ligne affiche une chaine de caracteres suivis de l'execution d'une commande qui va chercher des variables afin de le realiser
puts "Et en minutes ça fait : #{number_of_minutes_in_an_hour * number_of_hours_worked_per_day * number_of_days_worked_per_week * number_of_weeks_in_THP}" #Cette ligne affiche une chaine de caracteres suivis de l'execution d'une commande qui va chercher des variables afin de le realiser # la commande ne fonctionne pas les variable de son pas initialisé
