puts "Quel est  ton année de naissance ?"
print "> "
birth_year = gets.to_i
year_of_test = 2017


puts "Bonjour, #{year_of_test - birth_year}"
