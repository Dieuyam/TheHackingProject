user_name = gets.chomp
puts user_name

# Le programme A affiche un chaine de caracteres avant de recuperer les données utilisateur
# Le programme fait la même chose que le A, a la différence qu'il ajoute ">" devant l'espace ou l'utilisateur tape ses informations
#Le programme B ne fait que recuperer le prenom de l'utilisateur et l'afficher
