puts "Bonjour, c'est quoi ton blase ?"
user_name = gets.chomp #get.chomp recupere des données de l'utilisateur
puts user_name
