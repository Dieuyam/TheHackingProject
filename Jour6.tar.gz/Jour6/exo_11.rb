puts "Sur une echelle de 1 a infinie, a quelle point ça farte ?"
print "> "
farte = gets.to_i

farte.times do
puts "Salut, ça farte"
end
